const express = require('express');
const ctrl = require('../controllers/reports.controller');
const { upload } = require('../middleware/upload');
const { optionalAuth, requireAuth, requireRole, loadReport, ownerOrAdmin } = require('../middleware/auth');

const router = express.Router();

router.get('/', optionalAuth, ctrl.list);
router.get('/:id', optionalAuth, ctrl.get);
router.post('/', requireAuth, upload.single('image'), ctrl.create);
router.patch('/:id/status', requireAuth, loadReport, ownerOrAdmin, ctrl.setStatus);
router.delete('/:id', requireAuth, requireRole('admin'), loadReport, ctrl.remove);

module.exports = router;
